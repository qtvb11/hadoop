# zxl-hadoop
zxl-hadoop是一个大数据服务管理工具，基于Web界面，提供服务器集群的各种指标监控，并提供HDFS、MapReduce、Hive、Flink、Habase、Zookeeper、Kafka、Sqoop等大数据组件的一键式安装。

# 项目实现功能
![实现功能](https://whoiszxl-hexo.oss-cn-beijing.aliyuncs.com/zxl-hadoop/zxl-hadoop.png)