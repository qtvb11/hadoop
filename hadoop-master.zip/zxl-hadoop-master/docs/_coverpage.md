![logo](_media/-logo.png)

> 

* zxl-hadoop是一个大数据服务管理工具，基于Web界面，提供服务器集群的各种指标监控，并提供HDFS、MapReduce、Hive、Flink、Habase、Zookeeper、Kafka、Sqoop等大数据组件的一键式安装。

[Docs](https://zxl-hadoop.whoiszxl.com)
[Get Started](#zxl-hadoop)