## Hadoop Web 前端管理面板

### 创建流程

1. 初始化项目
```sh
# 创建工程
yarn create @vitejs/app zxl-hadoop-admin --template vue

# 安装依赖
yarn

# dev運行
yarn dev
```
