export default {
    dev: {
        baseUrl: '/api'
    },
    test: {
        baseUrl: '//localhost:81'
    },
    release: {
        baseUrl: '//zxl-hadoop.whoiszxl.com/'
    }
}