package com.whoiszxl.constants;

public interface SoftwareConfigNameConstants {

    String ZOO_CFG = "zoo.cfg";

    String KAFKA_SERVER_PROPERTIES = "server.properties";

    String FLUME_ENV_SH = "flume-env.sh";
}
