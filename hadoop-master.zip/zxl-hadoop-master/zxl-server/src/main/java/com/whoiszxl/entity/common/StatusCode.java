package com.whoiszxl.entity.common;

/**
 * 常用状态码
 *
 * @author whoiszxl
 * @date 2021/3/17
 */
public class StatusCode {
    public static final int OK = 0;//成功
    public static final int ERROR = 1;//失败
}