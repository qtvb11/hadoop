package com.whoiszxl.mapper;

import com.whoiszxl.entity.Admin;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 管理员表 Mapper 接口
 * </p>
 *
 * @author whoiszxl
 * @since 2021-08-13
 */
public interface AdminMapper extends BaseMapper<Admin> {

}
