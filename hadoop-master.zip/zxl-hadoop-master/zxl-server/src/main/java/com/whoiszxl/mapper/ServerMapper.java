package com.whoiszxl.mapper;

import com.whoiszxl.entity.Server;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 服务器表 Mapper 接口
 * </p>
 *
 * @author whoiszxl
 * @since 2021-08-12
 */
public interface ServerMapper extends BaseMapper<Server> {

}
